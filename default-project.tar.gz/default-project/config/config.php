<?php

$dbconfig  = parse_ini_file("database.ini", 1)



?>
